<?php
require_once __DIR__ . '/myclass/ham_chung.php';
header('Location: ' . duong_dan('frontend/index.php'));
exit;
