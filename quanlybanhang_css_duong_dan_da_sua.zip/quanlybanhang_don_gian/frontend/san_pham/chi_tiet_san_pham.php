<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
require_once dirname(__DIR__, 2) . '/myclass/Sanpham.php';
$ma_san_pham = isset($_GET['ma_so']) ? (int)$_GET['ma_so'] : 0;
$san_pham = (new Sanpham())->chi_tiet_san_pham($ma_san_pham);
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Chi tiết sản phẩm</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__) . '/bo_cuc/dau.php'; ?>
<main class="noidung">
    <h2>Chi tiết sản phẩm</h2>
    <?php if (!$san_pham) { ?>
        <div class="thong-bao-trong"><p>Không tìm thấy sản phẩm.</p><a class="nut" href="<?php echo thoat_html(duong_dan('frontend/index.php')); ?>">Quay lại trang chủ</a></div>
    <?php } else { ?>
        <div class="chi-tiet-san-pham">
            <div class="chi-tiet-anh"><img class="anh-san-pham-lon" src="<?php echo thoat_html(duong_dan_anh($san_pham['hinhanh'] ?? '')); ?>" alt="<?php echo thoat_html($san_pham['tensp']); ?>"></div>
            <div class="chi-tiet-thong-tin">
                <p class="ten-cong-ty"><?php echo thoat_html($san_pham['tencty']); ?></p>
                <h2><?php echo thoat_html($san_pham['tensp']); ?></h2>
                <p class="gia-san-pham gia-chi-tiet"><?php echo number_format((float)$san_pham['gia']); ?> VNĐ</p>
                <p><b>Mô tả:</b> <?php echo thoat_html($san_pham['mota']); ?></p>
                <p><b>Số lượng còn:</b> <?php echo (int)$san_pham['soluong']; ?></p>
                <?php if ((int)$san_pham['soluong'] > 0) { ?>
                    <p><a class="nut" href="<?php echo thoat_html(duong_dan('frontend/gio_hang/gio_hang.php?hanh_dong=them&ma_so=' . (int)$san_pham['id'])); ?>">Thêm vào giỏ hàng</a></p>
                <?php } else { ?><p><span class="het-hang">Sản phẩm đã hết hàng</span></p><?php } ?>
                <p><a class="nut nut-phu" href="<?php echo thoat_html(duong_dan('frontend/index.php')); ?>">Quay lại danh sách</a></p>
            </div>
        </div>
    <?php } ?>
</main>
<?php include dirname(__DIR__) . '/bo_cuc/cuoi.php'; ?>
</body>
</html>
