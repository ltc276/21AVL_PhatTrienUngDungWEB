<footer class="cuoi-trang">
    <p>Cửa hàng trực tuyến · Xây dựng bằng PHP hướng đối tượng và MySQLi</p>
</footer>
