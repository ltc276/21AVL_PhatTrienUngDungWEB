<?php $nguoi_dung_hien_tai = $_SESSION['nguoi_dung'] ?? null; ?>
<header class="dau-trang">
    <div class="dau-trang-trong">
        <a class="ten-website" href="<?php echo thoat_html(duong_dan('frontend/index.php')); ?>">Cửa hàng trực tuyến</a>
        <nav>
            <a href="<?php echo thoat_html(duong_dan('frontend/index.php')); ?>">Trang chủ</a>
            <a href="<?php echo thoat_html(duong_dan('frontend/gio_hang/gio_hang.php')); ?>">Giỏ hàng</a>
            <?php if ($nguoi_dung_hien_tai && (int)$nguoi_dung_hien_tai['role'] === 1) { ?>
                <a href="<?php echo thoat_html(duong_dan('backend/san_pham/danh_sach.php')); ?>">Quản lý sản phẩm</a>
                <a href="<?php echo thoat_html(duong_dan('backend/don_hang/danh_sach.php')); ?>">Quản lý đơn hàng</a>
                <a href="<?php echo thoat_html(duong_dan('backend/thong_ke/danh_sach.php')); ?>">Thống kê</a>
                <a href="<?php echo thoat_html(duong_dan('backend/dang_nhap/dang_xuat.php')); ?>">Đăng xuất</a>
            <?php } elseif ($nguoi_dung_hien_tai) { ?>
                <span class="xin-chao">Xin chào, <?php echo thoat_html($nguoi_dung_hien_tai['hoten']); ?></span>
                <a href="<?php echo thoat_html(duong_dan('backend/dang_nhap/dang_xuat.php')); ?>">Đăng xuất</a>
            <?php } else { ?>
                <a href="<?php echo thoat_html(duong_dan('backend/dang_nhap/dang_nhap.php')); ?>">Đăng nhập</a>
                <a href="<?php echo thoat_html(duong_dan('frontend/tai_khoan/dang_ky.php')); ?>">Đăng ký</a>
            <?php } ?>
        </nav>
    </div>
</header>
