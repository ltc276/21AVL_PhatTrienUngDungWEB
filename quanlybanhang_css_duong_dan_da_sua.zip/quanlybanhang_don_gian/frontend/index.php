<?php
session_start();
require_once dirname(__DIR__) . '/myclass/ham_chung.php';
require_once dirname(__DIR__) . '/myclass/Congty.php';
require_once dirname(__DIR__) . '/myclass/Sanpham.php';
$quan_ly_cong_ty = new Congty();
$quan_ly_san_pham = new Sanpham();
$danh_sach_cong_ty = $quan_ly_cong_ty->danh_sach();
$ma_cong_ty = isset($_GET['ma_cong_ty']) ? (int)$_GET['ma_cong_ty'] : 0;
$danh_sach_san_pham = $quan_ly_san_pham->danh_sach($ma_cong_ty);
$tat_ca_san_pham = $quan_ly_san_pham->danh_sach();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Trang chủ | Cửa hàng trực tuyến</title>
    <link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>">
</head>
<body>
<?php include __DIR__ . '/bo_cuc/dau.php'; ?>
<div class="khung">
    <aside class="cot-trai">
        <h2>Danh sách công ty</h2>
        <p class="dem-congty"><?php echo count($danh_sach_cong_ty); ?> công ty</p>
        <a class="congty-item <?php echo $ma_cong_ty === 0 ? 'dang-chon' : ''; ?>" href="<?php echo thoat_html(duong_dan('frontend/index.php')); ?>">
            <span>Tất cả công ty</span><span><?php echo count($tat_ca_san_pham); ?></span>
        </a>
        <?php foreach ($danh_sach_cong_ty as $cong_ty) { ?>
            <a class="congty-item <?php echo $ma_cong_ty === (int)$cong_ty['id'] ? 'dang-chon' : ''; ?>" href="<?php echo thoat_html(duong_dan('frontend/index.php?ma_cong_ty=' . (int)$cong_ty['id'])); ?>">
                <span><?php echo thoat_html($cong_ty['tencty']); ?></span><span class="mui-ten">›</span>
            </a>
        <?php } ?>
    </aside>
    <main class="cot-phai">
        <div class="tieu-de-khu-vuc">
            <div><h2>Danh sách sản phẩm</h2><p class="mo-ta-nho">Khám phá các sản phẩm đang được bán</p></div>
            <span class="nhan-so-luong"><?php echo count($danh_sach_san_pham); ?> sản phẩm</span>
        </div>
        <?php if (count($danh_sach_san_pham) === 0) { ?>
            <div class="thong-bao-trong"><h3>Chưa có sản phẩm</h3><p>Công ty này hiện chưa có sản phẩm nào.</p></div>
        <?php } else { ?>
            <div class="sanpham-grid">
                <?php foreach ($danh_sach_san_pham as $san_pham) { ?>
                <article class="the-san-pham">
                    <a class="khung-anh-san-pham" href="<?php echo thoat_html(duong_dan('frontend/san_pham/chi_tiet_san_pham.php?ma_so=' . (int)$san_pham['id'])); ?>">
                        <img src="<?php echo thoat_html(duong_dan_anh($san_pham['hinhanh'] ?? '')); ?>" alt="<?php echo thoat_html($san_pham['tensp']); ?>">
                    </a>
                    <div class="thong-tin-san-pham">
                        <h3><a href="<?php echo thoat_html(duong_dan('frontend/san_pham/chi_tiet_san_pham.php?ma_so=' . (int)$san_pham['id'])); ?>"><?php echo thoat_html($san_pham['tensp']); ?></a></h3>
                        <p class="ten-cong-ty"><?php echo thoat_html($san_pham['tencty']); ?></p>
                        <p class="gia-san-pham"><?php echo number_format((float)$san_pham['gia']); ?> VNĐ</p>
                        <p class="ton-kho">Còn <?php echo (int)$san_pham['soluong']; ?> sản phẩm</p>
                        <div class="nut-san-pham">
                            <a class="nut nut-phu" href="<?php echo thoat_html(duong_dan('frontend/san_pham/chi_tiet_san_pham.php?ma_so=' . (int)$san_pham['id'])); ?>">Chi tiết</a>
                            <?php if ((int)$san_pham['soluong'] > 0) { ?>
                                <a class="nut" href="<?php echo thoat_html(duong_dan('frontend/gio_hang/gio_hang.php?hanh_dong=them&ma_so=' . (int)$san_pham['id'])); ?>">Thêm vào giỏ</a>
                            <?php } else { ?><span class="het-hang">Hết hàng</span><?php } ?>
                        </div>
                    </div>
                </article>
                <?php } ?>
            </div>
        <?php } ?>
    </main>
</div>
<?php include __DIR__ . '/bo_cuc/cuoi.php'; ?>
</body>
</html>
