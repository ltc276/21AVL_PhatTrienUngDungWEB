<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
require_once dirname(__DIR__, 2) . '/myclass/Taikhoan.php';
if (isset($_SESSION['nguoi_dung'])) {
    header('Location: ' . duong_dan('frontend/index.php'));
    exit;
}
$thong_bao = '';
$thanh_cong = false;
if (isset($_POST['dang_ky'])) {
    $ho_ten = trim($_POST['ho_ten'] ?? '');
    $ten_dang_nhap = trim($_POST['ten_dang_nhap'] ?? '');
    $mat_khau = $_POST['mat_khau'] ?? '';
    $xac_nhan_mat_khau = $_POST['xac_nhan_mat_khau'] ?? '';
    if ($ho_ten === '' || $ten_dang_nhap === '' || $mat_khau === '') {
        $thong_bao = 'Vui lòng nhập đầy đủ thông tin.';
    } elseif (!preg_match('/^[a-zA-Z0-9_.-]{3,50}$/', $ten_dang_nhap)) {
        $thong_bao = 'Tên đăng nhập phải có từ 3 đến 50 ký tự, chỉ gồm chữ, số, dấu chấm, gạch ngang hoặc gạch dưới.';
    } elseif (strlen($mat_khau) < 6) {
        $thong_bao = 'Mật khẩu phải có ít nhất 6 ký tự.';
    } elseif ($mat_khau !== $xac_nhan_mat_khau) {
        $thong_bao = 'Mật khẩu xác nhận không khớp.';
    } else {
        $ket_qua = (new Taikhoan())->dang_ky($ten_dang_nhap, $mat_khau, $ho_ten);
        if ($ket_qua === 'trung_ten_dang_nhap') $thong_bao = 'Tên đăng nhập đã tồn tại.';
        elseif ($ket_qua) { $thanh_cong = true; $thong_bao = 'Đăng ký thành công. Tài khoản của bạn có quyền người dùng.'; }
        else $thong_bao = 'Đăng ký thất bại. Vui lòng thử lại.';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Đăng ký tài khoản</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__) . '/bo_cuc/dau.php'; ?>
<main class="noidung form-trang"><div class="hop-form">
    <h2>Đăng ký tài khoản</h2>
    <?php if ($thong_bao !== '') { ?><p class="thongbao <?php echo $thanh_cong ? 'thanh-cong' : 'loi'; ?>"><?php echo thoat_html($thong_bao); ?></p><?php } ?>
    <?php if (!$thanh_cong) { ?>
    <form method="post" class="form-don">
        <p>Họ và tên:<br><input type="text" name="ho_ten" value="<?php echo thoat_html($_POST['ho_ten'] ?? ''); ?>" required></p>
        <p>Tên đăng nhập:<br><input type="text" name="ten_dang_nhap" value="<?php echo thoat_html($_POST['ten_dang_nhap'] ?? ''); ?>" minlength="3" maxlength="50" required></p>
        <p>Mật khẩu (ít nhất 6 ký tự):<br><input type="password" name="mat_khau" minlength="6" required></p>
        <p>Nhập lại mật khẩu:<br><input type="password" name="xac_nhan_mat_khau" minlength="6" required></p>
        <button type="submit" name="dang_ky">Tạo tài khoản</button>
    </form>
    <?php } else { ?><p><a class="nut" href="<?php echo thoat_html(duong_dan('backend/dang_nhap/dang_nhap.php')); ?>">Đăng nhập</a></p><?php } ?>
    <p class="mo-ta-nho">Tài khoản đăng ký mới luôn được gán quyền người dùng (role = 2). Không thể tự đăng ký quyền quản trị viên.</p>
</div></main>
<?php include dirname(__DIR__) . '/bo_cuc/cuoi.php'; ?>
</body>
</html>
