<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
require_once dirname(__DIR__, 2) . '/myclass/Sanpham.php';
$quan_ly_san_pham = new Sanpham();
if (!isset($_SESSION['gio_hang'])) $_SESSION['gio_hang'] = [];
if (($_GET['hanh_dong'] ?? '') === 'them') {
    $ma_so = (int)($_GET['ma_so'] ?? 0);
    $san_pham = $quan_ly_san_pham->chi_tiet_san_pham($ma_so);
    if ($san_pham && (int)$san_pham['soluong'] > 0) {
        if (!isset($_SESSION['gio_hang'][$ma_so])) $_SESSION['gio_hang'][$ma_so] = 0;
        $_SESSION['gio_hang'][$ma_so]++;
    }
    header('Location: ' . duong_dan('frontend/gio_hang/gio_hang.php'));
    exit;
}
if (($_GET['hanh_dong'] ?? '') === 'xoa') {
    unset($_SESSION['gio_hang'][(int)($_GET['ma_so'] ?? 0)]);
    header('Location: ' . duong_dan('frontend/gio_hang/gio_hang.php'));
    exit;
}
if (isset($_POST['cap_nhat_gio_hang'])) {
    foreach (($_POST['so_luong'] ?? []) as $ma_so => $so_luong) {
        $ma_so = (int)$ma_so;
        $so_luong = (int)$so_luong;
        if ($so_luong <= 0) unset($_SESSION['gio_hang'][$ma_so]);
        else $_SESSION['gio_hang'][$ma_so] = $so_luong;
    }
    header('Location: ' . duong_dan('frontend/gio_hang/gio_hang.php'));
    exit;
}
$tat_ca_san_pham = $quan_ly_san_pham->danh_sach();
$san_pham_trong_gio = [];
$tong_tien = 0;
foreach ($tat_ca_san_pham as $san_pham) {
    if (isset($_SESSION['gio_hang'][$san_pham['id']])) {
        $san_pham['so_luong_mua'] = (int)$_SESSION['gio_hang'][$san_pham['id']];
        $san_pham['thanhtien'] = $san_pham['so_luong_mua'] * $san_pham['gia'];
        $tong_tien += $san_pham['thanhtien'];
        $san_pham_trong_gio[] = $san_pham;
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Giỏ hàng</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__) . '/bo_cuc/dau.php'; ?>
<main class="noidung">
    <h2>Giỏ hàng</h2>
    <?php if (count($san_pham_trong_gio) === 0) { ?><div class="thong-bao-trong"><p>Giỏ hàng của bạn đang trống.</p><a class="nut" href="<?php echo thoat_html(duong_dan('frontend/index.php')); ?>">Tiếp tục mua hàng</a></div><?php } else { ?>
    <form method="post"><div class="bang-co-the-cuon"><table>
        <tr><th>Sản phẩm</th><th>Đơn giá</th><th>Số lượng</th><th>Thành tiền</th><th>Thao tác</th></tr>
        <?php foreach ($san_pham_trong_gio as $san_pham) { ?>
        <tr>
            <td><?php echo thoat_html($san_pham['tensp']); ?></td><td><?php echo number_format((float)$san_pham['gia']); ?> VNĐ</td>
            <td><input class="input-so-luong" type="number" min="0" max="<?php echo (int)$san_pham['soluong']; ?>" name="so_luong[<?php echo (int)$san_pham['id']; ?>]" value="<?php echo (int)$san_pham['so_luong_mua']; ?>"></td>
            <td><?php echo number_format((float)$san_pham['thanhtien']); ?> VNĐ</td>
            <td><a class="nut nut-nguy-hiem nut-nho" href="<?php echo thoat_html(duong_dan('frontend/gio_hang/gio_hang.php?hanh_dong=xoa&ma_so=' . (int)$san_pham['id'])); ?>">Xóa</a></td>
        </tr>
        <?php } ?>
        <tr><th colspan="3">Tổng tiền</th><th colspan="2"><?php echo number_format((float)$tong_tien); ?> VNĐ</th></tr>
    </table></div>
    <div class="nhom-nut"><button type="submit" name="cap_nhat_gio_hang">Cập nhật giỏ hàng</button><a class="nut" href="<?php echo thoat_html(duong_dan('frontend/gio_hang/dat_hang.php')); ?>">Đặt hàng</a></div>
    </form>
    <?php } ?>
</main>
<?php include dirname(__DIR__) . '/bo_cuc/cuoi.php'; ?>
</body>
</html>
