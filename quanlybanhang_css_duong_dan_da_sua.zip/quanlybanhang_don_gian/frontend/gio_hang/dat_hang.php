<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
require_once dirname(__DIR__, 2) . '/myclass/Donhang.php';
if (empty($_SESSION['gio_hang'])) {
    header('Location: ' . duong_dan('frontend/gio_hang/gio_hang.php'));
    exit;
}
$thong_bao = '';
$ma_don_hang = 0;
if (isset($_POST['dat_hang'])) {
    $ho_ten = trim($_POST['ho_ten'] ?? '');
    $thu_dien_tu = trim($_POST['thu_dien_tu'] ?? '');
    $dia_chi = trim($_POST['dia_chi'] ?? '');
    if ($ho_ten === '' || $thu_dien_tu === '' || $dia_chi === '') $thong_bao = 'Vui lòng nhập đầy đủ thông tin.';
    elseif (!filter_var($thu_dien_tu, FILTER_VALIDATE_EMAIL)) $thong_bao = 'Địa chỉ email không hợp lệ.';
    else {
        $ma_don_hang = (new Donhang())->tao_don_hang($ho_ten, $thu_dien_tu, $dia_chi, $_SESSION['gio_hang']);
        if ($ma_don_hang) {
            $_SESSION['gio_hang'] = [];
            $thong_bao = 'Đặt hàng thành công. Mã đơn hàng của bạn là: ' . $ma_don_hang;
        } else $thong_bao = 'Không thể đặt hàng. Vui lòng kiểm tra lại sản phẩm và cơ sở dữ liệu.';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Đặt hàng</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__) . '/bo_cuc/dau.php'; ?>
<main class="noidung">
    <h2>Thông tin đặt hàng</h2>
    <?php if ($thong_bao !== '') { ?><p class="thongbao <?php echo $ma_don_hang ? 'thanh-cong' : 'loi'; ?>"><?php echo thoat_html($thong_bao); ?></p><?php } ?>
    <?php if (!$ma_don_hang) { ?>
    <form method="post" class="form-don">
        <p>Họ và tên:<br><input type="text" name="ho_ten" required></p>
        <p>Email:<br><input type="email" name="thu_dien_tu" required></p>
        <p>Địa chỉ giao hàng:<br><textarea name="dia_chi" required></textarea></p>
        <button type="submit" name="dat_hang">Xác nhận đặt hàng</button>
    </form>
    <?php } else { ?><p><a class="nut" href="<?php echo thoat_html(duong_dan('frontend/index.php')); ?>">Quay về trang chủ</a></p><?php } ?>
</main>
<?php include dirname(__DIR__) . '/bo_cuc/cuoi.php'; ?>
</body>
</html>
