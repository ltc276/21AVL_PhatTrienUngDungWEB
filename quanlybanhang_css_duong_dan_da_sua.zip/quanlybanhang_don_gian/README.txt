CỬA HÀNG TRỰC TUYẾN - PHP THUẦN, LẬP TRÌNH HƯỚNG ĐỐI TƯỢNG

1. Cấu trúc chính
- frontend/: giao diện khách hàng
- frontend/san_pham/: xem chi tiết sản phẩm
- frontend/gio_hang/: giỏ hàng và đặt hàng
- frontend/tai_khoan/: đăng ký tài khoản
- frontend/bo_cuc/: phần đầu và chân trang dùng chung
- backend/dang_nhap/: đăng nhập và đăng xuất quản trị
- backend/san_pham/: danh sách, thêm, sửa, xóa sản phẩm
- backend/don_hang/: quản lý đơn hàng
- backend/thong_ke/: thống kê bán hàng
- myclass/: các lớp PHP và hàm dùng chung
- css/style.css: giao diện
- hinh_anh/: ảnh sản phẩm

2. Các lớp và phương thức
- Ketnoi: kết nối cơ sở dữ liệu bằng ket_noi()
- Congty: lấy danh sách công ty bằng danh_sach()
- Sanpham: danh_sach(), chi_tiet_san_pham(), them(), cap_nhat(), xoa()
- Taikhoan: xac_thuc_dang_nhap(), dang_ky()
- Donhang: tao_don_hang(), danh_sach(), cap_nhat_trang_thai()
- Thongke: doanh_thu_theo_ngay(), doanh_thu_theo_thang(), doanh_thu_theo_nam(), san_pham_theo_thang(), san_pham_theo_nam()
- ham_chung.php: các hàm dùng chung có tên tiếng Việt

3. Cách chạy
- Đặt thư mục dự án trong C:\xampp\htdocs\quanlybanhang_don_gian
- Bật Apache và MySQL trong XAMPP
- Giữ nguyên cơ sở dữ liệu csdlot và các bảng hiện tại
- Mở myclass/Ketnoi.php và sửa thông tin MySQL nếu cần
- Đường dẫn website được đặt cố định là /quanlybanhang_don_gian trong hàm duong_dan() của myclass/ham_chung.php. Nếu đổi tên thư mục dự án, sửa DUONG_DAN_GOC tại đầu hàm này.
- Mở http://localhost/quanlybanhang_don_gian/

4. Lưu ý
- Tên bảng và cột trong MySQL được giữ nguyên để tương thích cơ sở dữ liệu hiện tại.
- Dữ liệu ảnh cũ lưu với đường dẫn uploads/ vẫn được hỗ trợ; ảnh mới được lưu trong hinh_anh/.
- Trạng thái đơn hàng trong cơ sở dữ liệu vẫn dùng giá trị nội bộ 'cho giao' và 'da giao'.
- Tài khoản đăng ký mới luôn có role = 2; chỉ role = 1 được mở trang quản trị.
- Nếu sản phẩm đã được dùng trong đơn hàng, hệ thống không cho xóa để giữ lịch sử giao dịch.
