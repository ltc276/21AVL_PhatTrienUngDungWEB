<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
kiem_tra_quyen_quan_tri();
require_once dirname(__DIR__, 2) . '/myclass/Sanpham.php';
$ma_so = isset($_GET['ma_so']) ? (int)$_GET['ma_so'] : 0;
$quan_ly_san_pham = new Sanpham();
$san_pham = $quan_ly_san_pham->chi_tiet_san_pham($ma_so);
if ($san_pham && $quan_ly_san_pham->xoa($ma_so)) {
    if (!empty($san_pham['hinhanh'])) xoa_anh_san_pham($san_pham['hinhanh']);
    header('Location: ' . duong_dan('backend/san_pham/danh_sach.php'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Không thể xóa sản phẩm</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head><body>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/dau.php'; ?>
<main class="noidung"><div class="thong-bao-trong"><h2>Không thể xóa sản phẩm</h2><p>Sản phẩm có thể đã được sử dụng trong đơn hàng. Hãy giữ lại sản phẩm này.</p><a class="nut" href="<?php echo thoat_html(duong_dan('backend/san_pham/danh_sach.php')); ?>">Quay lại quản lý sản phẩm</a></div></main>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/cuoi.php'; ?>
</body></html>
