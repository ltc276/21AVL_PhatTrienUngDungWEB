<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
kiem_tra_quyen_quan_tri();
require_once dirname(__DIR__, 2) . '/myclass/Sanpham.php';
require_once dirname(__DIR__, 2) . '/myclass/Congty.php';
$quan_ly_san_pham = new Sanpham();
$danh_sach_cong_ty = (new Congty())->danh_sach();
$thong_bao = '';
if (isset($_POST['them'])) {
    $loi_anh = '';
    $anh = tai_anh_san_pham($_FILES['anh'] ?? null, $loi_anh);
    if ($anh === false) $thong_bao = $loi_anh;
    else {
        $thanh_cong = $quan_ly_san_pham->them(trim($_POST['ten'] ?? ''), trim($_POST['mo_ta'] ?? ''), (float)($_POST['gia'] ?? 0), (int)($_POST['so_luong'] ?? 0), (int)($_POST['ma_cong_ty'] ?? 0), $anh);
        if ($thanh_cong) { header('Location: ' . duong_dan('backend/san_pham/danh_sach.php')); exit; }
        if ($anh !== '') xoa_anh_san_pham($anh);
        $thong_bao = 'Thêm sản phẩm thất bại. Vui lòng kiểm tra lại thông tin.';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Thêm sản phẩm</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/dau.php'; ?>
<main class="noidung">
    <h2>Thêm sản phẩm</h2>
    <?php if ($thong_bao !== '') { ?><p class="thongbao loi"><?php echo thoat_html($thong_bao); ?></p><?php } ?>
    <form method="post" enctype="multipart/form-data" class="form-don form-rong">
        <p>Tên sản phẩm:<br><input type="text" name="ten" required></p>
        <p>Mô tả:<br><textarea name="mo_ta" rows="4"></textarea></p>
        <p>Giá (VNĐ):<br><input type="number" name="gia" min="0" step="1000" required></p>
        <p>Số lượng:<br><input type="number" name="so_luong" min="0" required></p>
        <p>Công ty:<br><select name="ma_cong_ty" required><?php foreach ($danh_sach_cong_ty as $cong_ty) { ?><option value="<?php echo (int)$cong_ty['id']; ?>"><?php echo thoat_html($cong_ty['tencty']); ?></option><?php } ?></select></p>
        <p>Ảnh sản phẩm (JPG, PNG, GIF, WEBP; tối đa 2 MB):<br><input type="file" name="anh" accept="image/jpeg,image/png,image/gif,image/webp"></p>
        <div class="nhom-nut"><button type="submit" name="them">Thêm sản phẩm</button><a class="nut nut-phu" href="<?php echo thoat_html(duong_dan('backend/san_pham/danh_sach.php')); ?>">Quay lại</a></div>
    </form>
</main>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/cuoi.php'; ?>
</body>
</html>
