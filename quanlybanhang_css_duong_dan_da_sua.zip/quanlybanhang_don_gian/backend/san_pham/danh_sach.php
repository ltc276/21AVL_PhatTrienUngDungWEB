<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
kiem_tra_quyen_quan_tri();
require_once dirname(__DIR__, 2) . '/myclass/Sanpham.php';
$danh_sach_san_pham = (new Sanpham())->danh_sach();
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Quản lý sản phẩm</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/dau.php'; ?>
<main class="noidung">
    <div class="tieu-de-khu-vuc"><div><h2>Quản lý sản phẩm</h2><p class="mo-ta-nho">Thêm mới, cập nhật hoặc xóa sản phẩm trong cửa hàng.</p></div><a class="nut" href="<?php echo thoat_html(duong_dan('backend/san_pham/them_san_pham.php')); ?>">+ Thêm sản phẩm</a></div>
    <div class="bang-co-the-cuon"><table>
        <tr><th>Mã</th><th>Hình ảnh</th><th>Tên sản phẩm</th><th>Công ty</th><th>Giá</th><th>Số lượng</th><th>Thao tác</th></tr>
        <?php foreach ($danh_sach_san_pham as $san_pham) { ?>
        <tr>
            <td><?php echo (int)$san_pham['id']; ?></td>
            <td><img class="anh-san-pham-nho" src="<?php echo thoat_html(duong_dan_anh($san_pham['hinhanh'] ?? '')); ?>" alt="<?php echo thoat_html($san_pham['tensp']); ?>"></td>
            <td><?php echo thoat_html($san_pham['tensp']); ?></td><td><?php echo thoat_html($san_pham['tencty']); ?></td>
            <td><?php echo number_format((float)$san_pham['gia']); ?> VNĐ</td><td><?php echo (int)$san_pham['soluong']; ?></td>
            <td class="hanh-dong"><a class="nut nut-phu nut-nho" href="<?php echo thoat_html(duong_dan('backend/san_pham/sua_san_pham.php?ma_so=' . (int)$san_pham['id'])); ?>">Sửa</a> <a class="nut nut-nguy-hiem nut-nho" href="<?php echo thoat_html(duong_dan('backend/san_pham/xoa_san_pham.php?ma_so=' . (int)$san_pham['id'])); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')">Xóa</a></td>
        </tr>
        <?php } ?>
    </table></div>
    <?php if (!$danh_sach_san_pham) { ?><p class="thong-bao-trong">Chưa có sản phẩm nào.</p><?php } ?>
</main>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/cuoi.php'; ?>
</body>
</html>
