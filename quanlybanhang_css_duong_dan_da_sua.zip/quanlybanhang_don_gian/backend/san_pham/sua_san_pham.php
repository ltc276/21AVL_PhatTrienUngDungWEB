<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
kiem_tra_quyen_quan_tri();
require_once dirname(__DIR__, 2) . '/myclass/Sanpham.php';
require_once dirname(__DIR__, 2) . '/myclass/Congty.php';
$ma_so = isset($_GET['ma_so']) ? (int)$_GET['ma_so'] : (int)($_POST['ma_so'] ?? 0);
$quan_ly_san_pham = new Sanpham();
$san_pham = $quan_ly_san_pham->chi_tiet_san_pham($ma_so);
$danh_sach_cong_ty = (new Congty())->danh_sach();
$thong_bao = '';
if (!$san_pham) $thong_bao = 'Không tìm thấy sản phẩm.';
if ($san_pham && isset($_POST['luu'])) {
    $loi_anh = '';
    $anh_moi = tai_anh_san_pham($_FILES['anh'] ?? null, $loi_anh);
    if ($anh_moi === false) $thong_bao = $loi_anh;
    else {
        $duong_dan_anh_moi = $anh_moi === '' ? null : $anh_moi;
        $thanh_cong = $quan_ly_san_pham->sua($ma_so, trim($_POST['ten'] ?? ''), trim($_POST['mo_ta'] ?? ''), (float)($_POST['gia'] ?? 0), (int)($_POST['so_luong'] ?? 0), (int)($_POST['ma_cong_ty'] ?? 0), $duong_dan_anh_moi);
        if ($thanh_cong) {
            if ($anh_moi !== '' && !empty($san_pham['hinhanh'])) xoa_anh_san_pham($san_pham['hinhanh']);
            header('Location: ' . duong_dan('backend/san_pham/danh_sach.php')); exit;
        }
        if ($anh_moi !== '') xoa_anh_san_pham($anh_moi);
        $thong_bao = 'Không thể lưu thay đổi sản phẩm.';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Sửa sản phẩm</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/dau.php'; ?>
<main class="noidung">
    <h2>Sửa sản phẩm</h2>
    <?php if ($thong_bao !== '') { ?><p class="thongbao loi"><?php echo thoat_html($thong_bao); ?></p><?php } ?>
    <?php if ($san_pham) { ?>
    <form method="post" enctype="multipart/form-data" class="form-don form-rong">
        <input type="hidden" name="ma_so" value="<?php echo (int)$san_pham['id']; ?>">
        <p>Tên sản phẩm:<br><input type="text" name="ten" value="<?php echo thoat_html($san_pham['tensp']); ?>" required></p>
        <p>Mô tả:<br><textarea name="mo_ta" rows="4"><?php echo thoat_html($san_pham['mota']); ?></textarea></p>
        <p>Giá (VNĐ):<br><input type="number" name="gia" min="0" step="1000" value="<?php echo thoat_html($san_pham['gia']); ?>" required></p>
        <p>Số lượng:<br><input type="number" name="so_luong" min="0" value="<?php echo (int)$san_pham['soluong']; ?>" required></p>
        <p>Công ty:<br><select name="ma_cong_ty" required><?php foreach ($danh_sach_cong_ty as $cong_ty) { ?><option value="<?php echo (int)$cong_ty['id']; ?>" <?php if ((int)$cong_ty['id'] === (int)$san_pham['id_congty']) echo 'selected'; ?>><?php echo thoat_html($cong_ty['tencty']); ?></option><?php } ?></select></p>
        <p>Ảnh hiện tại:<br><img class="anh-san-pham-lon" src="<?php echo thoat_html(duong_dan_anh($san_pham['hinhanh'] ?? '')); ?>" alt="Ảnh sản phẩm"></p>
        <p>Chọn ảnh mới (để trống nếu muốn giữ ảnh cũ):<br><input type="file" name="anh" accept="image/jpeg,image/png,image/gif,image/webp"></p>
        <div class="nhom-nut"><button type="submit" name="luu">Lưu thay đổi</button><a class="nut nut-phu" href="<?php echo thoat_html(duong_dan('backend/san_pham/danh_sach.php')); ?>">Quay lại</a></div>
    </form>
    <?php } ?>
</main>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/cuoi.php'; ?>
</body>
</html>
