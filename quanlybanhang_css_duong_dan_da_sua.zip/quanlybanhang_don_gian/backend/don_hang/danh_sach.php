<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
kiem_tra_quyen_quan_tri();
require_once dirname(__DIR__, 2) . '/myclass/Donhang.php';
$quan_ly_don_hang = new Donhang();
$thong_bao = '';
if (isset($_POST['cap_nhat_trang_thai'])) {
    $thanh_cong = $quan_ly_don_hang->cap_nhat_trang_thai((int)($_POST['ma_so'] ?? 0), $_POST['trang_thai'] ?? '');
    $thong_bao = $thanh_cong ? 'Đã cập nhật trạng thái đơn hàng.' : 'Cập nhật trạng thái thất bại.';
}
$trang_thai = $_GET['trang_thai'] ?? '';
$danh_sach_don_hang = $quan_ly_don_hang->danh_sach($trang_thai);
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Quản lý đơn hàng</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/dau.php'; ?>
<main class="noidung">
    <h2>Quản lý đơn hàng</h2>
    <?php if ($thong_bao !== '') { ?><p class="thongbao <?php echo strpos($thong_bao, 'thất bại') !== false ? 'loi' : 'thanh-cong'; ?>"><?php echo thoat_html($thong_bao); ?></p><?php } ?>
    <div class="bo-loc"><span>Lọc đơn hàng:</span><a class="nut nut-phu nut-nho" href="<?php echo thoat_html(duong_dan('backend/don_hang/danh_sach.php')); ?>">Tất cả</a><a class="nut nut-phu nut-nho" href="<?php echo thoat_html(duong_dan('backend/don_hang/danh_sach.php?trang_thai=cho%20giao')); ?>">Chờ giao</a><a class="nut nut-phu nut-nho" href="<?php echo thoat_html(duong_dan('backend/don_hang/danh_sach.php?trang_thai=da%20giao')); ?>">Đã giao</a></div>
    <div class="bang-co-the-cuon"><table>
        <tr><th>Mã đơn</th><th>Khách hàng</th><th>Email</th><th>Địa chỉ</th><th>Sản phẩm</th><th>Ngày đặt</th><th>Tổng tiền</th><th>Trạng thái</th></tr>
        <?php foreach ($danh_sach_don_hang as $don_hang) { ?>
        <tr><td><?php echo (int)$don_hang['id']; ?></td><td><?php echo thoat_html($don_hang['hoten']); ?></td><td><?php echo thoat_html($don_hang['email']); ?></td><td><?php echo thoat_html($don_hang['diachi']); ?></td><td><?php echo thoat_html($don_hang['cac_san_pham']); ?></td><td><?php echo thoat_html($don_hang['ngaydat']); ?></td><td><?php echo number_format((float)$don_hang['tongtien']); ?> VNĐ</td>
            <td><form method="post" class="form-trangthai"><input type="hidden" name="ma_so" value="<?php echo (int)$don_hang['id']; ?>"><select name="trang_thai"><option value="cho giao" <?php if ($don_hang['trangthai'] === 'cho giao') echo 'selected'; ?>>Chờ giao</option><option value="da giao" <?php if ($don_hang['trangthai'] === 'da giao') echo 'selected'; ?>>Đã giao</option></select><button type="submit" name="cap_nhat_trang_thai">Lưu</button></form></td>
        </tr>
        <?php } ?>
    </table></div>
    <?php if (!$danh_sach_don_hang) { ?><p class="thong-bao-trong">Chưa có đơn hàng nào.</p><?php } ?>
</main>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/cuoi.php'; ?>
</body>
</html>
