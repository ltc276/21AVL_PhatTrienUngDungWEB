<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
kiem_tra_quyen_quan_tri();
require_once dirname(__DIR__, 2) . '/myclass/Thongke.php';
$thong_ke = new Thongke();
$nam = isset($_GET['nam']) ? (int)$_GET['nam'] : (int)date('Y');
$thang = isset($_GET['thang']) ? (int)$_GET['thang'] : (int)date('n');
if ($thang < 1 || $thang > 12) $thang = (int)date('n');
if ($nam < 2000 || $nam > 2100) $nam = (int)date('Y');
$doanh_thu_ngay = $thong_ke->doanh_thu_theo_ngay();
$doanh_thu_thang = $thong_ke->doanh_thu_theo_thang($nam);
$doanh_thu_nam = $thong_ke->doanh_thu_theo_nam();
$san_pham_theo_thang = $thong_ke->san_pham_theo_thang($nam, $thang);
$san_pham_theo_nam = $thong_ke->san_pham_theo_nam($nam);
function hien_bieu_do_san_pham($tieu_de, $cac_dong) {
    echo '<h3>' . thoat_html($tieu_de) . '</h3>';
    if (!$cac_dong) { echo '<p>Chưa có dữ liệu đơn hàng đã giao.</p>'; return; }
    $gia_tri_lon_nhat = 1;
    foreach ($cac_dong as $dong) if ((float)$dong['soluong'] > $gia_tri_lon_nhat) $gia_tri_lon_nhat = (float)$dong['soluong'];
    foreach ($cac_dong as $dong) {
        $chieu_rong = (int)((float)$dong['soluong'] * 100 / $gia_tri_lon_nhat);
        echo '<div class="hang-bieu-do"><span class="ten-bieu-do">' . thoat_html($dong['tensp']) . '</span><div class="nen-bieu-do"><div class="cot-bieu-do" style="width:' . $chieu_rong . '%"></div></div><span>' . (int)$dong['soluong'] . '</span></div>';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Thống kê bán hàng</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/dau.php'; ?>
<main class="noidung">
    <h2>Thống kê bán hàng</h2>
    <h3>Doanh thu theo ngày (10 ngày có đơn giao gần nhất)</h3>
    <div class="bang-co-the-cuon"><table><tr><th>Ngày</th><th>Doanh thu</th></tr><?php foreach ($doanh_thu_ngay as $dong) { ?><tr><td><?php echo thoat_html($dong['ngay']); ?></td><td><?php echo number_format((float)$dong['doanhthu']); ?> VNĐ</td></tr><?php } ?></table></div>
    <h3>Doanh thu theo tháng</h3>
    <form method="get" class="form-loc">
        <label>Năm: <input type="number" name="nam" value="<?php echo $nam; ?>" min="2000" max="2100"></label>
        <label>Tháng xem biểu đồ: <select name="thang"><?php for ($thang_lap = 1; $thang_lap <= 12; $thang_lap++) { ?><option value="<?php echo $thang_lap; ?>" <?php if ($thang === $thang_lap) echo 'selected'; ?>>Tháng <?php echo $thang_lap; ?></option><?php } ?></select></label>
        <button type="submit">Xem thống kê</button>
    </form>
    <div class="bang-co-the-cuon"><table><tr><th>Tháng</th><th>Doanh thu</th></tr><?php foreach ($doanh_thu_thang as $dong) { ?><tr><td>Tháng <?php echo (int)$dong['thang']; ?></td><td><?php echo number_format((float)$dong['doanhthu']); ?> VNĐ</td></tr><?php } ?></table></div>
    <h3>Doanh thu theo năm</h3>
    <div class="bang-co-the-cuon"><table><tr><th>Năm</th><th>Doanh thu</th></tr><?php foreach ($doanh_thu_nam as $dong) { ?><tr><td><?php echo (int)$dong['nam']; ?></td><td><?php echo number_format((float)$dong['doanhthu']); ?> VNĐ</td></tr><?php } ?></table></div>
    <h2>Biểu đồ sản phẩm đã bán</h2>
    <?php hien_bieu_do_san_pham('Sản phẩm bán được trong tháng ' . $thang . '/' . $nam, $san_pham_theo_thang); ?>
    <?php hien_bieu_do_san_pham('Sản phẩm bán được trong năm ' . $nam, $san_pham_theo_nam); ?>
</main>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/cuoi.php'; ?>
</body>
</html>
