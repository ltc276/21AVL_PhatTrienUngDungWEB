<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
$_SESSION = [];
session_destroy();
header('Location: ' . duong_dan('frontend/index.php'));
exit;
