<?php
session_start();
require_once dirname(__DIR__, 2) . '/myclass/ham_chung.php';
require_once dirname(__DIR__, 2) . '/myclass/Taikhoan.php';
if (isset($_SESSION['nguoi_dung'])) {
    $trang_dich = (int)$_SESSION['nguoi_dung']['role'] === 1 ? 'backend/san_pham/danh_sach.php' : 'frontend/index.php';
    header('Location: ' . duong_dan($trang_dich));
    exit;
}
$loi = '';
if (isset($_POST['dang_nhap'])) {
    $nguoi_dung = (new Taikhoan())->xac_thuc_dang_nhap(trim($_POST['ten_dang_nhap'] ?? ''), $_POST['mat_khau'] ?? '');
    if ($nguoi_dung) {
        session_regenerate_id(true);
        $_SESSION['nguoi_dung'] = $nguoi_dung;
        $trang_dich = (int)$nguoi_dung['role'] === 1 ? 'backend/san_pham/danh_sach.php' : 'frontend/index.php';
        header('Location: ' . duong_dan($trang_dich));
        exit;
    }
    $loi = 'Tên đăng nhập hoặc mật khẩu không chính xác.';
}
?>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Đăng nhập</title><link rel="stylesheet" href="<?php echo thoat_html(duong_dan('css/style.css?v=20261027_fix2')); ?>"></head>
<body>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/dau.php'; ?>
<main class="noidung form-trang"><div class="hop-form">
    <h2>Đăng nhập</h2>
    <p class="mo-ta-nho">Tài khoản quản trị viên được vào khu vực quản lý. Tài khoản người dùng sẽ trở về trang chủ.</p>
    <?php if ($loi !== '') { ?><p class="thongbao loi"><?php echo thoat_html($loi); ?></p><?php } ?>
    <form method="post" class="form-don">
        <p>Tên đăng nhập:<br><input type="text" name="ten_dang_nhap" autocomplete="username" required></p>
        <p>Mật khẩu:<br><input type="password" name="mat_khau" autocomplete="current-password" required></p>
        <button type="submit" name="dang_nhap">Đăng nhập</button>
    </form>
    <p class="mo-ta-nho">Chưa có tài khoản? <a href="<?php echo thoat_html(duong_dan('frontend/tai_khoan/dang_ky.php')); ?>">Đăng ký tài khoản người dùng</a></p>
</div></main>
<?php include dirname(__DIR__, 2) . '/frontend/bo_cuc/cuoi.php'; ?>
</body>
</html>
