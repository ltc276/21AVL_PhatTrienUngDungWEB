<?php
session_start();
require_once dirname(__DIR__) . '/myclass/ham_chung.php';
if (isset($_SESSION['nguoi_dung']) && (int)$_SESSION['nguoi_dung']['role'] === 1) {
    header('Location: ' . duong_dan('backend/san_pham/danh_sach.php'));
} else {
    header('Location: ' . duong_dan('frontend/index.php'));
}
exit;
