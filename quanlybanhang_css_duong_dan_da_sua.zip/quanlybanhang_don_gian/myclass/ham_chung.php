<?php
function thoat_html($gia_tri) {
    return htmlspecialchars((string)$gia_tri, ENT_QUOTES, 'UTF-8');
}

// Đường dẫn URL cố định theo vị trí dự án trong XAMPP:
// C:\xampp\htdocs\quanlybanhang_don_gian
// Nếu đổi tên thư mục dự án, chỉ cần sửa DUONG_DAN_GOC tại đây.
if (!defined('DUONG_DAN_GOC')) {
    define('DUONG_DAN_GOC', '/quanlybanhang_don_gian');
}

function duong_dan($duong_dan_tuong_doi = '') {
    $duong_dan_tuong_doi = ltrim((string)$duong_dan_tuong_doi, '/');
    if ($duong_dan_tuong_doi === '') {
        return DUONG_DAN_GOC . '/';
    }
    return rtrim(DUONG_DAN_GOC, '/') . '/' . $duong_dan_tuong_doi;
}

function duong_dan_anh($duong_dan_tuong_doi) {
    if (trim((string)$duong_dan_tuong_doi) === '') {
        return duong_dan('hinh_anh/khong_co_anh.svg');
    }
    $duong_dan_tuong_doi = ltrim((string)$duong_dan_tuong_doi, '/');
    // Tương thích với đường dẫn ảnh cũ đang lưu trong database.
    if (strpos($duong_dan_tuong_doi, 'uploads/') === 0) {
        $duong_dan_tuong_doi = 'hinh_anh/' . substr($duong_dan_tuong_doi, strlen('uploads/'));
    }
    return duong_dan($duong_dan_tuong_doi);
}

function tai_anh_san_pham($tep, &$loi = '') {
    if (!isset($tep) || $tep['error'] === UPLOAD_ERR_NO_FILE) return '';
    if ($tep['error'] !== UPLOAD_ERR_OK) {
        $loi = 'Tải ảnh lên thất bại. Vui lòng thử lại.';
        return false;
    }
    if ($tep['size'] > 2 * 1024 * 1024) {
        $loi = 'Ảnh không được lớn hơn 2 MB.';
        return false;
    }
    $thong_tin_anh = @getimagesize($tep['tmp_name']);
    if ($thong_tin_anh === false) {
        $loi = 'Tệp đã chọn không phải là ảnh hợp lệ.';
        return false;
    }
    $loai_tep_cho_phep = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp'
    ];
    if (!isset($loai_tep_cho_phep[$thong_tin_anh['mime']])) {
        $loi = 'Chỉ chấp nhận ảnh JPG, PNG, GIF hoặc WEBP.';
        return false;
    }
    $ten_tep = uniqid('san_pham_', true) . '.' . $loai_tep_cho_phep[$thong_tin_anh['mime']];
    $thu_muc_tai_anh = dirname(__DIR__) . '/hinh_anh/';
    if (!is_dir($thu_muc_tai_anh)) mkdir($thu_muc_tai_anh, 0755, true);
    if (!move_uploaded_file($tep['tmp_name'], $thu_muc_tai_anh . $ten_tep)) {
        $loi = 'Không thể lưu ảnh. Hãy kiểm tra quyền ghi của thư mục hinh_anh.';
        return false;
    }
    return 'hinh_anh/' . $ten_tep;
}

function xoa_anh_san_pham($duong_dan_tuong_doi) {
    $ten_tep = basename((string)$duong_dan_tuong_doi);
    if ($ten_tep === '') return;
    if (strpos((string)$duong_dan_tuong_doi, 'uploads/') !== 0 && strpos((string)$duong_dan_tuong_doi, 'hinh_anh/') !== 0) return;
    $duong_dan_tep = dirname(__DIR__) . '/hinh_anh/' . $ten_tep;
    if (is_file($duong_dan_tep)) unlink($duong_dan_tep);
}

function kiem_tra_quyen_quan_tri() {
    if (!isset($_SESSION['nguoi_dung']) || (int)$_SESSION['nguoi_dung']['role'] !== 1) {
        header('Location: ' . duong_dan('frontend/index.php'));
        exit;
    }
}
