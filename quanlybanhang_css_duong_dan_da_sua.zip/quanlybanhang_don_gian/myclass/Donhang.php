<?php
require_once __DIR__ . '/Ketnoi.php';

class Donhang {
    private $co_so_du_lieu;

    public function __construct() {
        $this->co_so_du_lieu = new Ketnoi();
    }

    public function tao_don_hang($ho_ten, $thu_dien_tu, $dia_chi, $gio_hang) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $ket_noi->begin_transaction();
        $cau_lenh = $ket_noi->prepare("INSERT INTO donhang (hoten, email, diachi, ngaydat, trangthai) VALUES (?, ?, ?, NOW(), 'cho giao')");
        $cau_lenh->bind_param('sss', $ho_ten, $thu_dien_tu, $dia_chi);
        if (!$cau_lenh->execute()) {
            $ket_noi->rollback();
            $cau_lenh->close();
            $ket_noi->close();
            return false;
        }
        $ma_don_hang = $ket_noi->insert_id;
        $cau_lenh->close();
        foreach ($gio_hang as $ma_san_pham => $so_luong) {
            $ma_san_pham = (int)$ma_san_pham;
            $so_luong = (int)$so_luong;
            if ($so_luong < 1) continue;
            $truy_van_gia = $ket_noi->prepare('SELECT gia FROM sanpham WHERE id=?');
            $truy_van_gia->bind_param('i', $ma_san_pham);
            $truy_van_gia->execute();
            $san_pham = $truy_van_gia->get_result()->fetch_assoc();
            $truy_van_gia->close();
            if (!$san_pham) {
                $ket_noi->rollback();
                $ket_noi->close();
                return false;
            }
            $gia = (float)$san_pham['gia'];
            $chi_tiet = $ket_noi->prepare('INSERT INTO chitietdonhang (id_donhang, id_sanpham, soluong, dongia) VALUES (?, ?, ?, ?)');
            $chi_tiet->bind_param('iiid', $ma_don_hang, $ma_san_pham, $so_luong, $gia);
            if (!$chi_tiet->execute()) {
                $ket_noi->rollback();
                $chi_tiet->close();
                $ket_noi->close();
                return false;
            }
            $chi_tiet->close();
        }
        $ket_noi->commit();
        $ket_noi->close();
        return $ma_don_hang;
    }

    public function danh_sach($trang_thai = '') {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh_sql = "SELECT d.*, GROUP_CONCAT(CONCAT(s.tensp, ' x', ct.soluong) SEPARATOR ', ') AS cac_san_pham, SUM(ct.soluong * ct.dongia) AS tongtien FROM donhang d LEFT JOIN chitietdonhang ct ON d.id = ct.id_donhang LEFT JOIN sanpham s ON ct.id_sanpham = s.id";
        if ($trang_thai === 'cho giao' || $trang_thai === 'da giao') $cau_lenh_sql .= ' WHERE d.trangthai = ?';
        $cau_lenh_sql .= ' GROUP BY d.id ORDER BY d.id DESC';
        if ($trang_thai === 'cho giao' || $trang_thai === 'da giao') {
            $cau_lenh = $ket_noi->prepare($cau_lenh_sql);
            $cau_lenh->bind_param('s', $trang_thai);
            $cau_lenh->execute();
            $ket_qua = $cau_lenh->get_result();
        } else {
            $ket_qua = $ket_noi->query($cau_lenh_sql);
        }
        $danh_sach_don_hang = [];
        if ($ket_qua) while ($dong = $ket_qua->fetch_assoc()) $danh_sach_don_hang[] = $dong;
        if (isset($cau_lenh)) $cau_lenh->close();
        $ket_noi->close();
        return $danh_sach_don_hang;
    }

    public function cap_nhat_trang_thai($ma_so, $trang_thai) {
        if ($trang_thai !== 'cho giao' && $trang_thai !== 'da giao') return false;
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh = $ket_noi->prepare('UPDATE donhang SET trangthai=? WHERE id=?');
        $cau_lenh->bind_param('si', $trang_thai, $ma_so);
        $thanh_cong = $cau_lenh->execute();
        $cau_lenh->close();
        $ket_noi->close();
        return $thanh_cong;
    }
}
