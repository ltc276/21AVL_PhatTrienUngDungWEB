<?php
require_once __DIR__ . '/Ketnoi.php';

class Taikhoan {
    private $co_so_du_lieu;

    public function __construct() {
        $this->co_so_du_lieu = new Ketnoi();
    }

    public function xac_thuc_dang_nhap($ten_dang_nhap, $mat_khau) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh = $ket_noi->prepare('SELECT id, username, password, hoten, role FROM nguoidung WHERE username = ?');
        $cau_lenh->bind_param('s', $ten_dang_nhap);
        $cau_lenh->execute();
        $ket_qua = $cau_lenh->get_result();
        $nguoi_dung = $ket_qua->fetch_assoc();
        $cau_lenh->close();
        $ket_noi->close();
        if ($nguoi_dung && password_verify($mat_khau, $nguoi_dung['password'])) {
            unset($nguoi_dung['password']);
            return $nguoi_dung;
        }
        return false;
    }

    public function dang_ky($ten_dang_nhap, $mat_khau, $ho_ten) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $kiem_tra = $ket_noi->prepare('SELECT id FROM nguoidung WHERE username = ?');
        $kiem_tra->bind_param('s', $ten_dang_nhap);
        $kiem_tra->execute();
        $ket_qua = $kiem_tra->get_result();
        if ($ket_qua->num_rows > 0) {
            $kiem_tra->close();
            $ket_noi->close();
            return 'trung_ten_dang_nhap';
        }
        $kiem_tra->close();
        $mat_khau_ma_hoa = password_hash($mat_khau, PASSWORD_DEFAULT);
        $vai_tro = 2;
        $cau_lenh = $ket_noi->prepare('INSERT INTO nguoidung (username, password, hoten, role) VALUES (?, ?, ?, ?)');
        $cau_lenh->bind_param('sssi', $ten_dang_nhap, $mat_khau_ma_hoa, $ho_ten, $vai_tro);
        $thanh_cong = $cau_lenh->execute();
        $cau_lenh->close();
        $ket_noi->close();
        return $thanh_cong;
    }
}
