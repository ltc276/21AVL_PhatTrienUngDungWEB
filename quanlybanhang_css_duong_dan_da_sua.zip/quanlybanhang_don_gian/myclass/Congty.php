<?php
require_once __DIR__ . '/Ketnoi.php';

class Congty {
    private $co_so_du_lieu;

    public function __construct() {
        $this->co_so_du_lieu = new Ketnoi();
    }

    public function danh_sach() {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $ket_qua = $ket_noi->query('SELECT * FROM congty ORDER BY id');
        $danh_sach_cong_ty = [];
        if ($ket_qua) {
            while ($dong = $ket_qua->fetch_assoc()) $danh_sach_cong_ty[] = $dong;
        }
        $ket_noi->close();
        return $danh_sach_cong_ty;
    }
}
