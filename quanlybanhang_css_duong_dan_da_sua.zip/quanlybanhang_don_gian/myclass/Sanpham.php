<?php
require_once __DIR__ . '/Ketnoi.php';

class Sanpham {
    private $co_so_du_lieu;

    public function __construct() {
        $this->co_so_du_lieu = new Ketnoi();
    }

    public function danh_sach($ma_cong_ty = 0) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh_sql = 'SELECT s.*, c.tencty FROM sanpham s LEFT JOIN congty c ON s.id_congty = c.id';
        if ($ma_cong_ty > 0) {
            $cau_lenh = $ket_noi->prepare($cau_lenh_sql . ' WHERE s.id_congty = ? ORDER BY s.id DESC');
            $cau_lenh->bind_param('i', $ma_cong_ty);
            $cau_lenh->execute();
            $ket_qua = $cau_lenh->get_result();
        } else {
            $ket_qua = $ket_noi->query($cau_lenh_sql . ' ORDER BY s.id DESC');
        }
        $danh_sach_san_pham = [];
        if ($ket_qua) while ($dong = $ket_qua->fetch_assoc()) $danh_sach_san_pham[] = $dong;
        if (isset($cau_lenh)) $cau_lenh->close();
        $ket_noi->close();
        return $danh_sach_san_pham;
    }

    public function chi_tiet_san_pham($ma_so) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh = $ket_noi->prepare('SELECT s.*, c.tencty FROM sanpham s LEFT JOIN congty c ON s.id_congty = c.id WHERE s.id = ?');
        $cau_lenh->bind_param('i', $ma_so);
        $cau_lenh->execute();
        $ket_qua = $cau_lenh->get_result();
        $san_pham = $ket_qua->fetch_assoc();
        $cau_lenh->close();
        $ket_noi->close();
        return $san_pham;
    }

    public function them($ten, $mo_ta, $gia, $so_luong, $ma_cong_ty, $anh = '') {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh = $ket_noi->prepare('INSERT INTO sanpham (tensp, mota, gia, soluong, id_congty, hinhanh) VALUES (?, ?, ?, ?, ?, ?)');
        $cau_lenh->bind_param('ssdiis', $ten, $mo_ta, $gia, $so_luong, $ma_cong_ty, $anh);
        $thanh_cong = $cau_lenh->execute();
        $cau_lenh->close();
        $ket_noi->close();
        return $thanh_cong;
    }

    public function sua($ma_so, $ten, $mo_ta, $gia, $so_luong, $ma_cong_ty, $anh = null) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        if ($anh === null) {
            $cau_lenh = $ket_noi->prepare('UPDATE sanpham SET tensp=?, mota=?, gia=?, soluong=?, id_congty=? WHERE id=?');
            $cau_lenh->bind_param('ssdiii', $ten, $mo_ta, $gia, $so_luong, $ma_cong_ty, $ma_so);
        } else {
            $cau_lenh = $ket_noi->prepare('UPDATE sanpham SET tensp=?, mota=?, gia=?, soluong=?, id_congty=?, hinhanh=? WHERE id=?');
            $cau_lenh->bind_param('ssdiisi', $ten, $mo_ta, $gia, $so_luong, $ma_cong_ty, $anh, $ma_so);
        }
        $thanh_cong = $cau_lenh->execute();
        $cau_lenh->close();
        $ket_noi->close();
        return $thanh_cong;
    }

    public function xoa($ma_so) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        // Chỉ xóa sản phẩm chưa từng được dùng trong chi tiết đơn hàng.
        $kiem_tra = $ket_noi->prepare('SELECT COUNT(*) AS tong FROM chitietdonhang WHERE id_sanpham = ?');
        $kiem_tra->bind_param('i', $ma_so);
        $kiem_tra->execute();
        $dong = $kiem_tra->get_result()->fetch_assoc();
        $kiem_tra->close();
        if ((int)$dong['tong'] > 0) {
            $ket_noi->close();
            return false;
        }
        $cau_lenh = $ket_noi->prepare('DELETE FROM sanpham WHERE id=?');
        $cau_lenh->bind_param('i', $ma_so);
        $thanh_cong = $cau_lenh->execute();
        $cau_lenh->close();
        $ket_noi->close();
        return $thanh_cong;
    }
}
