<?php
class Ketnoi {
    private $may_chu = 'localhost';
    private $tai_khoan = 'admin1';
    private $mat_khau = 'abc@123';
    private $ten_co_so_du_lieu = 'csdlot';

    public function ket_noi() {
        $ket_noi = new mysqli($this->may_chu, $this->tai_khoan, $this->mat_khau, $this->ten_co_so_du_lieu);
        if ($ket_noi->connect_error) {
            die('Lỗi kết nối cơ sở dữ liệu: ' . $ket_noi->connect_error);
        }
        $ket_noi->set_charset('utf8mb4');
        return $ket_noi;
    }
}
