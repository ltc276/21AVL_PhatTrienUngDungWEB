<?php
require_once __DIR__ . '/Ketnoi.php';

class Thongke {
    private $co_so_du_lieu;

    public function __construct() {
        $this->co_so_du_lieu = new Ketnoi();
    }

    public function doanh_thu_theo_ngay() {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $ket_qua = $ket_noi->query("SELECT DATE(d.ngaydat) AS ngay, SUM(ct.soluong * ct.dongia) AS doanhthu FROM donhang d JOIN chitietdonhang ct ON d.id=ct.id_donhang WHERE d.trangthai='da giao' GROUP BY DATE(d.ngaydat) ORDER BY ngay DESC LIMIT 10");
        $cac_dong = [];
        if ($ket_qua) while ($dong = $ket_qua->fetch_assoc()) $cac_dong[] = $dong;
        $ket_noi->close();
        return $cac_dong;
    }

    public function doanh_thu_theo_thang($nam) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh = $ket_noi->prepare("SELECT MONTH(d.ngaydat) AS thang, SUM(ct.soluong * ct.dongia) AS doanhthu FROM donhang d JOIN chitietdonhang ct ON d.id=ct.id_donhang WHERE d.trangthai='da giao' AND YEAR(d.ngaydat)=? GROUP BY MONTH(d.ngaydat) ORDER BY thang");
        $cau_lenh->bind_param('i', $nam);
        $cau_lenh->execute();
        $ket_qua = $cau_lenh->get_result();
        $cac_dong = [];
        while ($dong = $ket_qua->fetch_assoc()) $cac_dong[] = $dong;
        $cau_lenh->close();
        $ket_noi->close();
        return $cac_dong;
    }

    public function doanh_thu_theo_nam() {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $ket_qua = $ket_noi->query("SELECT YEAR(d.ngaydat) AS nam, SUM(ct.soluong * ct.dongia) AS doanhthu FROM donhang d JOIN chitietdonhang ct ON d.id=ct.id_donhang WHERE d.trangthai='da giao' GROUP BY YEAR(d.ngaydat) ORDER BY nam DESC");
        $cac_dong = [];
        if ($ket_qua) while ($dong = $ket_qua->fetch_assoc()) $cac_dong[] = $dong;
        $ket_noi->close();
        return $cac_dong;
    }

    public function san_pham_theo_thang($nam, $thang) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh = $ket_noi->prepare("SELECT s.tensp, SUM(ct.soluong) AS soluong FROM donhang d JOIN chitietdonhang ct ON d.id=ct.id_donhang JOIN sanpham s ON ct.id_sanpham=s.id WHERE d.trangthai='da giao' AND YEAR(d.ngaydat)=? AND MONTH(d.ngaydat)=? GROUP BY s.id, s.tensp ORDER BY soluong DESC");
        $cau_lenh->bind_param('ii', $nam, $thang);
        $cau_lenh->execute();
        $ket_qua = $cau_lenh->get_result();
        $cac_dong = [];
        while ($dong = $ket_qua->fetch_assoc()) $cac_dong[] = $dong;
        $cau_lenh->close();
        $ket_noi->close();
        return $cac_dong;
    }

    public function san_pham_theo_nam($nam) {
        $ket_noi = $this->co_so_du_lieu->ket_noi();
        $cau_lenh = $ket_noi->prepare("SELECT s.tensp, SUM(ct.soluong) AS soluong FROM donhang d JOIN chitietdonhang ct ON d.id=ct.id_donhang JOIN sanpham s ON ct.id_sanpham=s.id WHERE d.trangthai='da giao' AND YEAR(d.ngaydat)=? GROUP BY s.id, s.tensp ORDER BY soluong DESC");
        $cau_lenh->bind_param('i', $nam);
        $cau_lenh->execute();
        $ket_qua = $cau_lenh->get_result();
        $cac_dong = [];
        while ($dong = $ket_qua->fetch_assoc()) $cac_dong[] = $dong;
        $cau_lenh->close();
        $ket_noi->close();
        return $cac_dong;
    }
}
